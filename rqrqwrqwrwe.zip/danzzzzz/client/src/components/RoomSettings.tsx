import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings, 
  Users, 
  Video, 
  MessageCircle, 
  Eye, 
  EyeOff,
  Trash2,
  Crown,
  UserMinus
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface RoomSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  roomId: string;
  roomName?: string;
  users: User[];
  currentUser: User;
  settings?: {
    allowGuestControl: boolean;
    requireApproval: boolean;
    chatEnabled: boolean;
    isPublic: boolean;
  };
  onUpdateSettings?: (settings: any) => void;
  onKickUser?: (userId: string) => void;
  onPromoteUser?: (userId: string) => void;
  onDeleteRoom?: () => void;
}

export default function RoomSettings({
  isOpen,
  onClose,
  roomId,
  roomName = `Комната ${roomId.slice(-4)}`,
  users,
  currentUser,
  settings = {
    allowGuestControl: false,
    requireApproval: true,
    chatEnabled: true,
    isPublic: false
  },
  onUpdateSettings,
  onKickUser,
  onPromoteUser,
  onDeleteRoom
}: RoomSettingsProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  const [newRoomName, setNewRoomName] = useState(roomName);
  const { toast } = useToast();

  const handleSettingsChange = (key: string, value: boolean) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    onUpdateSettings?.(newSettings);
    
    toast({
      title: "Настройки обновлены",
      description: "Изменения применены для всех участников",
    });
  };

  const handleKickUser = (userId: string, username: string) => {
    onKickUser?.(userId);
    toast({
      title: "Участник исключен",
      description: `${username} был исключен из комнаты`,
    });
  };

  const handlePromoteUser = (userId: string, username: string) => {
    onPromoteUser?.(userId);
    toast({
      title: "Права предоставлены",
      description: `${username} теперь может управлять видео`,
    });
  };

  const handleDeleteRoom = () => {
    if (confirm('Вы уверены, что хотите удалить комнату? Это действие нельзя отменить.')) {
      onDeleteRoom?.();
      onClose();
      toast({
        title: "Комната удалена",
        description: "Все участники были уведомлены",
      });
    }
  };

  const otherUsers = users.filter(u => u.id !== currentUser.id);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            <DialogTitle>Настройки комнаты</DialogTitle>
          </div>
        </DialogHeader>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">Общие</TabsTrigger>
            <TabsTrigger value="participants">Участники</TabsTrigger>
            <TabsTrigger value="advanced">Дополнительно</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  Управление видео
                </CardTitle>
                <CardDescription>
                  Настройте, кто может управлять воспроизведением видео
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="guest-control">Разрешить гостям управление</Label>
                    <p className="text-sm text-muted-foreground">
                      Участники могут ставить на паузу и перематывать видео
                    </p>
                  </div>
                  <Switch
                    id="guest-control"
                    checked={localSettings.allowGuestControl}
                    onCheckedChange={(checked) => handleSettingsChange('allowGuestControl', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="require-approval">Требовать подтверждение</Label>
                    <p className="text-sm text-muted-foreground">
                      Новые участники должны получить разрешение на вход
                    </p>
                  </div>
                  <Switch
                    id="require-approval"
                    checked={localSettings.requireApproval}
                    onCheckedChange={(checked) => handleSettingsChange('requireApproval', checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Настройки чата
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="chat-enabled">Включить чат</Label>
                    <p className="text-sm text-muted-foreground">
                      Участники могут отправлять сообщения
                    </p>
                  </div>
                  <Switch
                    id="chat-enabled"
                    checked={localSettings.chatEnabled}
                    onCheckedChange={(checked) => handleSettingsChange('chatEnabled', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="participants" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Участники ({users.length})
                </CardTitle>
                <CardDescription>
                  Управляйте участниками комнаты
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {users.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
                          style={{ backgroundColor: user.color }}
                        >
                          {user.username[0].toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{user.username}</span>
                            {user.isHost && <Badge variant="default" className="text-xs">Хост</Badge>}
                            {user.id === currentUser.id && <Badge variant="outline" className="text-xs">Вы</Badge>}
                          </div>
                        </div>
                      </div>
                      
                      {user.id !== currentUser.id && (
                        <div className="flex gap-2">
                          {!user.isHost && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handlePromoteUser(user.id, user.username)}
                            >
                              <Crown className="w-3 h-3 mr-1" />
                              Дать права
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleKickUser(user.id, user.username)}
                          >
                            <UserMinus className="w-3 h-3 mr-1" />
                            Исключить
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Приватность
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="public-room">Публичная комната</Label>
                    <p className="text-sm text-muted-foreground">
                      Комната будет видна в общем списке
                    </p>
                  </div>
                  <Switch
                    id="public-room"
                    checked={localSettings.isPublic}
                    onCheckedChange={(checked) => handleSettingsChange('isPublic', checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Информация о комнате</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="room-name">Название комнаты</Label>
                  <Input
                    id="room-name"
                    value={newRoomName}
                    onChange={(e) => setNewRoomName(e.target.value)}
                    placeholder="Введите название комнаты"
                  />
                </div>
                <div className="space-y-2">
                  <Label>ID комнаты</Label>
                  <div className="font-mono text-sm p-2 bg-muted rounded">{roomId}</div>
                </div>
              </CardContent>
            </Card>

            <Separator />

            <Card>
              <CardHeader>
                <CardTitle className="text-destructive flex items-center gap-2">
                  <Trash2 className="w-4 h-4" />
                  Опасная зона
                </CardTitle>
                <CardDescription>
                  Необратимые действия
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  variant="destructive"
                  onClick={handleDeleteRoom}
                  className="w-full"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Удалить комнату
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={onClose}>
            Закрыть
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}