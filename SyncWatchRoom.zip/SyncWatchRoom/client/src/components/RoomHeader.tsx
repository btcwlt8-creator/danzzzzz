import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Copy, Share2, LogOut, Settings, Users, Link2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface RoomHeaderProps {
  roomId: string;
  roomUrl?: string;
  participantCount: number;
  isHost?: boolean;
  onLeaveRoom?: () => void;
  onRoomSettings?: () => void;
}

export default function RoomHeader({
  roomId,
  roomUrl,
  participantCount,
  isHost = false,
  onLeaveRoom,
  onRoomSettings
}: RoomHeaderProps) {
  const [showShareDialog, setShowShareDialog] = useState(false);
  const { toast } = useToast();

  const currentUrl = roomUrl || `${window.location.origin}/room/${roomId}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      toast({
        title: 'Ссылка скопирована!',
        description: 'Теперь вы можете поделиться ей с друзьями',
      });
      console.log('Room link copied:', currentUrl);
    } catch (err) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось скопировать ссылку',
        variant: 'destructive',
      });
    }
  };

  const handleLeaveRoom = () => {
    onLeaveRoom?.();
    console.log('Left room:', roomId);
  };

  const formatRoomId = (id: string) => {
    return id.length > 8 ? `${id.slice(0, 8)}...` : id;
  };

  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex items-center justify-between p-4">
        {/* Left side - Room info */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold">SyncWatch</h1>
            <Badge variant="outline" className="font-mono text-xs" data-testid="room-id-badge">
              {formatRoomId(roomId)}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="w-4 h-4" />
            <span data-testid="participant-count">{participantCount} участник{participantCount > 1 ? 'а' : ''}</span>
          </div>

          {isHost && (
            <Badge variant="default" className="text-xs">
              Хост
            </Badge>
          )}
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-2">
          {/* Share Room Dialog */}
          <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" data-testid="button-share-room">
                <Share2 className="w-4 h-4 mr-2" />
                Поделиться
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Поделиться комнатой</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Отправьте эту ссылку друзьям, чтобы они могли присоединиться к просмотру
                </p>
                <Card className="p-3">
                  <div className="flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-muted-foreground" />
                    <Input
                      value={currentUrl}
                      readOnly
                      className="flex-1 font-mono text-sm"
                      data-testid="input-room-url"
                    />
                    <Button
                      size="sm"
                      onClick={handleCopyLink}
                      data-testid="button-copy-link"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              </div>
            </DialogContent>
          </Dialog>

          {/* Settings (Host only) */}
          {isHost && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onRoomSettings}
              data-testid="button-room-settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
          )}

          {/* Leave Room */}
          <Button
            variant="outline"
            size="sm"
            onClick={handleLeaveRoom}
            data-testid="button-leave-room"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Покинуть
          </Button>
        </div>
      </div>
    </header>
  );
}