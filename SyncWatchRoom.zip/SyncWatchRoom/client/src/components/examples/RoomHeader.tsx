import RoomHeader from '../RoomHeader';

export default function RoomHeaderExample() {
  return (
    <div className="w-full">
      <RoomHeader
        roomId="abc123def456"
        participantCount={4}
        isHost={true}
        onLeaveRoom={() => console.log('Leave room triggered')}
        onRoomSettings={() => console.log('Room settings triggered')}
      />
    </div>
  );
}