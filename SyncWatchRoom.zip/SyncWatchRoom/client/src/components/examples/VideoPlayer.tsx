import VideoPlayer from '../VideoPlayer';
import { useState } from 'react';

export default function VideoPlayerExample() {
  const [videoUrl, setVideoUrl] = useState('');
  
  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <VideoPlayer
        isHost={true}
        isConnected={true}
        participantCount={3}
        videoUrl={videoUrl}
        onVideoLoad={(url) => setVideoUrl(url)}
        onPlay={() => console.log('Play triggered')}
        onPause={() => console.log('Pause triggered')}
        onSeek={(time) => console.log('Seek to:', time)}
      />
    </div>
  );
}