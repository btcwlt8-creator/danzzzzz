import { useState } from 'react';
import VideoPlayer from './VideoPlayer';
import ChatPanel from './ChatPanel';
import RoomHeader from './RoomHeader';
import { Button } from '@/components/ui/button';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerClose,
} from '@/components/ui/drawer';
import { MessageCircle, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface WatchRoomProps {
  roomId: string;
  currentUser: User;
  users?: User[];
  messages?: Message[];
  videoUrl?: string;
  isConnected?: boolean;
  onVideoLoad?: (url: string) => void;
  onPlay?: () => void;
  onPause?: () => void;
  onSeek?: (time: number) => void;
  onSendMessage?: (message: string) => void;
  onLeaveRoom?: () => void;
  onRoomSettings?: () => void;
}

export default function WatchRoom({
  roomId,
  currentUser,
  users = [],
  messages = [],
  videoUrl,
  isConnected = true,
  onVideoLoad,
  onPlay,
  onPause,
  onSeek,
  onSendMessage,
  onLeaveRoom,
  onRoomSettings
}: WatchRoomProps) {
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isMobileChatOpen, setIsMobileChatOpen] = useState(false);

  const toggleChat = () => {
    if (window.innerWidth < 768) {
      setIsMobileChatOpen(!isMobileChatOpen);
    } else {
      setIsChatOpen(!isChatOpen);
    }
    console.log('Chat toggled');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background overflow-x-hidden">
      {/* Header */}
      <RoomHeader
        roomId={roomId}
        participantCount={users.length}
        isHost={currentUser.isHost}
        onLeaveRoom={onLeaveRoom}
        onRoomSettings={onRoomSettings}
      />

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden flex-wrap gap-0">
        {/* Video Area */}
        <div className="flex-1 flex flex-col min-w-0 min-w-[280px]">
          <div className="flex-1 p-2 md:p-4">
            <VideoPlayer
              isHost={currentUser.isHost}
              isConnected={isConnected}
              participantCount={users.length}
              videoUrl={videoUrl}
              onVideoLoad={onVideoLoad}
              onPlay={onPlay}
              onPause={onPause}
              onSeek={onSeek}
            />
          </div>
          
          {/* Mobile Chat Toggle */}
          <div className="md:hidden p-2 border-t border-border">
            <Button
              onClick={toggleChat}
              variant="outline"
              className="w-full"
              data-testid="button-mobile-chat-toggle"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Чат ({messages.filter(m => m.type === 'user').length})
            </Button>
          </div>
        </div>

        {/* Desktop Chat Panel */}
        <div className={cn(
          "hidden md:flex transition-all duration-300 flex-shrink-0",
          isChatOpen ? "w-80 max-w-[calc(100vw-320px)]" : "w-0"
        )}>
          {isChatOpen && (
            <ChatPanel
              messages={messages}
              users={users}
              currentUsername={currentUser.username}
              onSendMessage={onSendMessage}
              onToggle={() => setIsChatOpen(false)}
            />
          )}
        </div>

        {/* Chat Toggle Button for Desktop */}
        {!isChatOpen && (
          <div className="hidden md:flex items-center p-2 border-l border-border flex-shrink-0">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsChatOpen(true)}
              data-testid="button-open-chat"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Mobile Chat Drawer */}
      <Drawer open={isMobileChatOpen} onOpenChange={setIsMobileChatOpen}>
        <DrawerContent className="h-[85vh] md:hidden">
          <DrawerHeader className="pb-0">
            <div className="flex items-center justify-between">
              <DrawerTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-primary" />
                Чат
              </DrawerTitle>
              <DrawerClose asChild>
                <Button
                  size="icon"
                  variant="ghost"
                  data-testid="button-close-mobile-chat"
                >
                  <X className="w-4 h-4" />
                </Button>
              </DrawerClose>
            </div>
          </DrawerHeader>
          <div className="flex-1 overflow-hidden">
            <ChatPanel
              messages={messages}
              users={users}
              currentUsername={currentUser.username}
              onSendMessage={onSendMessage}
              className="h-full border-0 rounded-none"
            />
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}