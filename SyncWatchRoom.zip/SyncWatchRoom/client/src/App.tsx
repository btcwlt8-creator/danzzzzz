import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useState } from "react";
import WelcomeScreen from "@/components/WelcomeScreen";
import WatchRoom from "@/components/WatchRoom";
import NotFound from "@/pages/not-found";

// Mock data for demo - todo: remove mock functionality
interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface RoomState {
  id: string;
  currentUser: User;
  users: User[];
  messages: Message[];
  videoUrl?: string;
}

const getUserColor = (username: string) => {
  const colors = [
    'hsl(220, 70%, 60%)',
    'hsl(280, 70%, 60%)', 
    'hsl(160, 70%, 50%)',
    'hsl(40, 70%, 60%)',
    'hsl(320, 70%, 60%)',
    'hsl(200, 70%, 60%)'
  ];
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
};

function Router() {
  const [currentRoom, setCurrentRoom] = useState<RoomState | null>(null);
  
  const handleCreateRoom = (username: string) => {
    // todo: remove mock functionality
    const roomId = `room-${Date.now()}`;
    const currentUser: User = {
      id: '1',
      username,
      isHost: true,
      color: getUserColor(username)
    };
    
    const initialMessage: Message = {
      id: '1',
      type: 'system',
      content: `${username} создал комнату`,
      timestamp: new Date()
    };
    
    setCurrentRoom({
      id: roomId,
      currentUser,
      users: [currentUser],
      messages: [initialMessage],
      videoUrl: undefined
    });
    
    console.log('Created room:', roomId, 'for user:', username);
  };
  
  const handleJoinRoom = (roomId: string, username: string) => {
    // todo: remove mock functionality
    const currentUser: User = {
      id: Date.now().toString(),
      username,
      isHost: false,
      color: getUserColor(username)
    };
    
    // Mock existing room data
    const existingUsers: User[] = [
      {
        id: '1',
        username: 'Хост',
        isHost: true,
        color: 'hsl(220, 70%, 60%)'
      }
    ];
    
    const existingMessages: Message[] = [
      {
        id: '1',
        type: 'system',
        content: 'Хост создал комнату',
        timestamp: new Date(Date.now() - 300000)
      },
      {
        id: '2',
        type: 'user',
        username: 'Хост',
        content: 'Добро пожаловать! Скоро начнем просмотр',
        timestamp: new Date(Date.now() - 120000),
        userColor: 'hsl(220, 70%, 60%)'
      }
    ];
    
    const joinMessage: Message = {
      id: Date.now().toString(),
      type: 'system',
      content: `${username} присоединился к комнате`,
      timestamp: new Date()
    };
    
    setCurrentRoom({
      id: roomId,
      currentUser,
      users: [...existingUsers, currentUser],
      messages: [...existingMessages, joinMessage],
      videoUrl: undefined
    });
    
    console.log('Joined room:', roomId, 'as:', username);
  };
  
  const handleLeaveRoom = () => {
    setCurrentRoom(null);
    console.log('Left room');
  };
  
  const handleSendMessage = (content: string) => {
    if (!currentRoom) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      username: currentRoom.currentUser.username,
      content,
      timestamp: new Date(),
      userColor: currentRoom.currentUser.color
    };
    
    setCurrentRoom(prev => prev ? {
      ...prev,
      messages: [...prev.messages, newMessage]
    } : null);
  };
  
  const handleVideoLoad = (url: string) => {
    if (!currentRoom) return;
    
    setCurrentRoom(prev => prev ? {
      ...prev,
      videoUrl: url
    } : null);
    
    const videoLoadMessage: Message = {
      id: Date.now().toString(),
      type: 'system',
      content: 'Видео загружено и готово к просмотру',
      timestamp: new Date()
    };
    
    setCurrentRoom(prev => prev ? {
      ...prev,
      messages: [...prev.messages, videoLoadMessage]
    } : null);
  };
  
  return (
    <Switch>
      <Route path="/">
        {currentRoom ? (
          <WatchRoom
            roomId={currentRoom.id}
            currentUser={currentRoom.currentUser}
            users={currentRoom.users}
            messages={currentRoom.messages}
            videoUrl={currentRoom.videoUrl}
            isConnected={true}
            onVideoLoad={handleVideoLoad}
            onPlay={() => console.log('Play triggered')}
            onPause={() => console.log('Pause triggered')}
            onSeek={(time) => console.log('Seek to:', time)}
            onSendMessage={handleSendMessage}
            onLeaveRoom={handleLeaveRoom}
            onRoomSettings={() => console.log('Room settings triggered')}
          />
        ) : (
          <WelcomeScreen
            onCreateRoom={handleCreateRoom}
            onJoinRoom={handleJoinRoom}
          />
        )}
      </Route>
      <Route path="/room/:id">
        {(routeProps: any) => {
          const params = routeProps.params;
          if (!currentRoom) {
            return (
              <WelcomeScreen
                onCreateRoom={handleCreateRoom}
                onJoinRoom={(_, username) => handleJoinRoom(params.id, username)}
              />
            );
          }
          
          return (
            <WatchRoom
              roomId={currentRoom.id}
              currentUser={currentRoom.currentUser}
              users={currentRoom.users}
              messages={currentRoom.messages}
              videoUrl={currentRoom.videoUrl}
              isConnected={true}
              onVideoLoad={handleVideoLoad}
              onPlay={() => console.log('Play triggered')}
              onPause={() => console.log('Pause triggered')}
              onSeek={(time) => console.log('Seek to:', time)}
              onSendMessage={handleSendMessage}
              onLeaveRoom={handleLeaveRoom}
              onRoomSettings={() => console.log('Room settings triggered')}
            />
          );
        }}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
