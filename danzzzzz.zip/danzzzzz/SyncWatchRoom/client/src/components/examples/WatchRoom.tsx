import WatchRoom from '../WatchRoom';
import { useState } from 'react';

export default function WatchRoomExample() {
  const [messages, setMessages] = useState([
    {
      id: '1',
      type: 'system' as const,
      content: 'Алексей создал комнату',
      timestamp: new Date(Date.now() - 300000)
    },
    {
      id: '2',
      type: 'user' as const,
      username: 'Алексей',
      content: 'Привет! Сейчас загружу фильм',
      timestamp: new Date(Date.now() - 240000),
      userColor: 'hsl(220, 70%, 60%)'
    },
    {
      id: '3',
      type: 'user' as const,
      username: 'Мария',
      content: 'Отлично! Жду не дождусь',
      timestamp: new Date(Date.now() - 180000),
      userColor: 'hsl(280, 70%, 60%)'
    }
  ]);

  const [videoUrl, setVideoUrl] = useState('');

  const currentUser = {
    id: '1',
    username: 'Алексей',
    isHost: true,
    color: 'hsl(220, 70%, 60%)'
  };

  const users = [
    currentUser,
    {
      id: '2',
      username: 'Мария',
      isHost: false,
      color: 'hsl(280, 70%, 60%)'
    },
    {
      id: '3',
      username: 'Дмитрий',
      isHost: false,
      color: 'hsl(160, 70%, 50%)'
    }
  ];

  const handleSendMessage = (content: string) => {
    const newMessage = {
      id: Date.now().toString(),
      type: 'user' as const,
      username: currentUser.username,
      content,
      timestamp: new Date(),
      userColor: currentUser.color
    };
    setMessages(prev => [...prev, newMessage]);
  };

  return (
    <div className="h-screen">
      <WatchRoom
        roomId="demo-room-123"
        currentUser={currentUser}
        users={users}
        messages={messages}
        videoUrl={videoUrl}
        isConnected={true}
        onVideoLoad={(url) => setVideoUrl(url)}
        onPlay={() => console.log('Play triggered')}
        onPause={() => console.log('Pause triggered')}
        onSeek={(time) => console.log('Seek to:', time)}
        onSendMessage={handleSendMessage}
        onLeaveRoom={() => console.log('Leave room triggered')}
        onRoomSettings={() => console.log('Room settings triggered')}
      />
    </div>
  );
}