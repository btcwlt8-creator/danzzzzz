import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Upload, Users, Wifi, WifiOff, Maximize, Minimize } from 'lucide-react';

interface VideoPlayerProps {
  isHost?: boolean;
  isConnected?: boolean;
  participantCount?: number;
  videoUrl?: string;
  onVideoLoad?: (url: string) => void;
  onPlay?: () => void;
  onPause?: () => void;
  onSeek?: (time: number) => void;
}

export default function VideoPlayer({
  isHost = false,
  isConnected = true,
  participantCount = 1,
  videoUrl,
  onVideoLoad,
  onPlay,
  onPause,
  onSeek
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [urlInput, setUrlInput] = useState('');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isFullscreenSupported, setIsFullscreenSupported] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout>();

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause?.();
      videoRef.current?.pause();
    } else {
      onPlay?.();
      videoRef.current?.play();
    }
    setIsPlaying(!isPlaying);
    console.log(isPlaying ? 'Video paused' : 'Video played');
  };

  const handleLoadVideo = () => {
    if (urlInput.trim()) {
      onVideoLoad?.(urlInput);
      console.log('Video loaded:', urlInput);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
    onSeek?.(time);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const checkFullscreenSupport = () => {
    return !!(
      document.fullscreenEnabled || 
      (document as any).webkitFullscreenEnabled || 
      (document as any).mozFullScreenEnabled || 
      (document as any).msFullscreenEnabled
    );
  };

  const enterFullscreen = async () => {
    const container = containerRef.current;
    if (!container) return;

    try {
      if (container.requestFullscreen) {
        await container.requestFullscreen();
      } else if ((container as any).webkitRequestFullscreen) {
        await (container as any).webkitRequestFullscreen();
      } else if ((container as any).mozRequestFullScreen) {
        await (container as any).mozRequestFullScreen();
      } else if ((container as any).msRequestFullscreen) {
        await (container as any).msRequestFullscreen();
      }
    } catch (error) {
      console.error('Error entering fullscreen:', error);
    }
  };

  const exitFullscreen = async () => {
    try {
      if (document.exitFullscreen) {
        await document.exitFullscreen();
      } else if ((document as any).webkitExitFullscreen) {
        await (document as any).webkitExitFullscreen();
      } else if ((document as any).mozCancelFullScreen) {
        await (document as any).mozCancelFullScreen();
      } else if ((document as any).msExitFullscreen) {
        await (document as any).msExitFullscreen();
      }
    } catch (error) {
      console.error('Error exiting fullscreen:', error);
    }
  };

  const toggleFullscreen = () => {
    if (isFullscreen) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
  };

  const handleFullscreenChange = () => {
    const isCurrentlyFullscreen = !!(document.fullscreenElement || 
                                    (document as any).webkitFullscreenElement || 
                                    (document as any).mozFullScreenElement || 
                                    (document as any).msFullscreenElement);
    setIsFullscreen(isCurrentlyFullscreen);
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateTime = () => setCurrentTime(video.currentTime);
    const updateDuration = () => setDuration(video.duration);

    video.addEventListener('timeupdate', updateTime);
    video.addEventListener('loadedmetadata', updateDuration);

    return () => {
      video.removeEventListener('timeupdate', updateTime);
      video.removeEventListener('loadedmetadata', updateDuration);
    };
  }, [videoUrl]);

  useEffect(() => {
    // Check fullscreen support on mount
    setIsFullscreenSupported(checkFullscreenSupport());

    // Listen for fullscreen changes
    const events = ['fullscreenchange', 'webkitfullscreenchange', 'mozfullscreenchange', 'MSFullscreenChange'];
    events.forEach(event => {
      document.addEventListener(event, handleFullscreenChange);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handleFullscreenChange);
      });
    };
  }, []);

  return (
    <div className="relative bg-card rounded-lg overflow-hidden aspect-video w-full">
      {/* Status Bar */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        <Badge variant={isConnected ? "default" : "destructive"} className="flex items-center gap-1">
          {isConnected ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
          {isConnected ? 'Подключено' : 'Отключено'}
        </Badge>
        <Badge variant="secondary" className="flex items-center gap-1">
          <Users className="w-3 h-3" />
          {participantCount}
        </Badge>
        {isHost && <Badge variant="outline">Хост</Badge>}
      </div>

      {!videoUrl ? (
        // Upload state
        <div className="flex flex-col items-center justify-center h-full p-8 text-center">
          <Upload className="w-16 h-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">Загрузить видео</h3>
          <p className="text-muted-foreground mb-6">
            {isHost 
              ? 'Вставьте прямую ссылку на видео файл для начала просмотра'
              : 'Ожидание загрузки видео от хоста...'}
          </p>
          {isHost && (
            <div className="flex gap-2 w-full max-w-md">
              <Input
                placeholder="https://example.com/video.mp4"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLoadVideo()}
                data-testid="input-video-url"
              />
              <Button onClick={handleLoadVideo} data-testid="button-load-video">
                Загрузить
              </Button>
            </div>
          )}
        </div>
      ) : (
        // Video player
        <div 
          ref={containerRef}
          className="relative h-full"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => isPlaying && setShowControls(false)}
          data-testid="video-player-container"
        >
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full object-contain bg-black"
            onClick={handlePlayPause}
            data-testid="video-element"
          />
          
          {/* Controls Overlay */}
          <div 
            className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 transition-opacity duration-300 ${
              showControls ? 'opacity-100' : 'opacity-0'
            }`}
          >
            {/* Play/Pause Button */}
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                size="icon"
                variant="secondary"
                onClick={handlePlayPause}
                className="w-16 h-16 rounded-full bg-background/80 hover:bg-background/90"
                data-testid="button-play-pause"
              >
                {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
              </Button>
            </div>

            {/* Bottom Controls */}
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <div className="flex items-center gap-3 text-white">
                <span className="text-sm font-mono" data-testid="text-current-time">
                  {formatTime(currentTime)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  value={currentTime}
                  onChange={handleSeek}
                  className="flex-1 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  data-testid="input-seek-bar"
                />
                <span className="text-sm font-mono" data-testid="text-duration">
                  {formatTime(duration)}
                </span>
                {isFullscreenSupported && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={toggleFullscreen}
                    className="w-8 h-8 text-white hover:bg-white/20"
                    data-testid="button-fullscreen"
                    aria-label={isFullscreen ? 'Выйти из полноэкранного режима' : 'Полноэкранный режим'}
                  >
                    {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}