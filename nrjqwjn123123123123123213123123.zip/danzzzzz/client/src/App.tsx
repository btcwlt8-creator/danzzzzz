import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import WelcomeScreen from "@/components/WelcomeScreen";
import WatchRoom from "@/components/WatchRoom";
import NotFound from "@/pages/not-found";
import { useWebSocket } from "@/hooks/use-websocket";

function Router() {
  const { 
    roomState,
    createRoom,
    joinRoom,
    loadVideo,
    playVideo,
    pauseVideo,
    seekVideo,
    sendMessage,
    leaveRoom
  } = useWebSocket();

  const currentRoom = roomState.currentUser ? roomState : null;
  
  return (
    <Switch>
      <Route path="/room/:id">
        {(params: any) => {
          const roomId = params.id;
          if (!currentRoom) {
            return (
              <WelcomeScreen
                onCreateRoom={createRoom}
                onJoinRoom={(_, username) => joinRoom(roomId, username)}
                autoJoinRoomId={roomId}
              />
            );
          }
          
          return (
            <WatchRoom
              roomId={currentRoom.roomId}
              currentUser={currentRoom.currentUser!}
              users={currentRoom.users}
              messages={currentRoom.messages}
              videoUrl={currentRoom.videoUrl}
              initialCurrentTime={currentRoom.currentTime}
              initialIsPlaying={currentRoom.isPlaying}
              isConnected={currentRoom.isConnected}
              onVideoLoad={loadVideo}
              onPlay={playVideo}
              onPause={pauseVideo}
              onSeek={seekVideo}
              onSendMessage={sendMessage}
              onLeaveRoom={leaveRoom}
              onRoomSettings={() => console.log('Room settings triggered')}
            />
          );
        }}
      </Route>
      <Route path="/">
        {currentRoom ? (
          <WatchRoom
            roomId={currentRoom.roomId}
            currentUser={currentRoom.currentUser!}
            users={currentRoom.users}
            messages={currentRoom.messages}
            videoUrl={currentRoom.videoUrl}
            initialCurrentTime={currentRoom.currentTime}
            initialIsPlaying={currentRoom.isPlaying}
            isConnected={currentRoom.isConnected}
            onVideoLoad={loadVideo}
            onPlay={playVideo}
            onPause={pauseVideo}
            onSeek={seekVideo}
            onSendMessage={sendMessage}
            onLeaveRoom={leaveRoom}
            onRoomSettings={() => console.log('Room settings triggered')}
          />
        ) : (
          <WelcomeScreen
            onCreateRoom={createRoom}
            onJoinRoom={joinRoom}
          />
        )}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
