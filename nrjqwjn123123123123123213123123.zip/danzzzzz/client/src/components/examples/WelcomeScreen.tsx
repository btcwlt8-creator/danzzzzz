import WelcomeScreen from '../WelcomeScreen';

export default function WelcomeScreenExample() {
  return (
    <WelcomeScreen
      onCreateRoom={(username) => console.log('Create room for:', username)}
      onJoinRoom={(roomId, username) => console.log('Join room:', roomId, 'as:', username)}
    />
  );
}