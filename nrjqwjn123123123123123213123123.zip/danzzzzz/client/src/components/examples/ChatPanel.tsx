import ChatPanel from '../ChatPanel';
import { useState } from 'react';

export default function ChatPanelExample() {
  const [messages, setMessages] = useState([
    {
      id: '1',
      type: 'system' as const,
      content: 'Алексей присоединился к комнате',
      timestamp: new Date(Date.now() - 300000)
    },
    {
      id: '2',
      type: 'user' as const,
      username: 'Алексей',
      content: 'Привет всем! Готовы смотреть фильм?',
      timestamp: new Date(Date.now() - 240000),
      userColor: 'hsl(220, 70%, 60%)'
    },
    {
      id: '3',
      type: 'user' as const,
      username: 'Мария',
      content: 'Да, давно ждала этого момента!',
      timestamp: new Date(Date.now() - 180000),
      userColor: 'hsl(280, 70%, 60%)'
    },
    {
      id: '4',
      type: 'user' as const,
      username: 'Дмитрий',
      content: 'Кто-то принес попкорн? 🍿',
      timestamp: new Date(Date.now() - 120000),
      userColor: 'hsl(160, 70%, 50%)'
    }
  ]);

  const users = [
    {
      id: '1',
      username: 'Алексей',
      isHost: true,
      color: 'hsl(220, 70%, 60%)'
    },
    {
      id: '2',
      username: 'Мария',
      isHost: false,
      color: 'hsl(280, 70%, 60%)'
    },
    {
      id: '3',
      username: 'Дмитрий',
      isHost: false,
      color: 'hsl(160, 70%, 50%)'
    }
  ];

  const handleSendMessage = (content: string) => {
    const newMessage = {
      id: Date.now().toString(),
      type: 'user' as const,
      username: 'Алексей',
      content,
      timestamp: new Date(),
      userColor: 'hsl(220, 70%, 60%)'
    };
    setMessages(prev => [...prev, newMessage]);
  };

  return (
    <div className="h-96 w-80">
      <ChatPanel
        messages={messages}
        users={users}
        currentUsername="Алексей"
        onSendMessage={handleSendMessage}
      />
    </div>
  );
}