import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Send, Users, X, MessageCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface ChatPanelProps {
  isOpen?: boolean;
  onToggle?: () => void;
  messages?: Message[];
  users?: User[];
  currentUsername?: string;
  onSendMessage?: (message: string) => void;
  className?: string;
  inlineMode?: boolean;
}

const getUserColor = (username: string) => {
  const colors = [
    'hsl(220, 70%, 60%)',
    'hsl(280, 70%, 60%)', 
    'hsl(160, 70%, 50%)',
    'hsl(40, 70%, 60%)',
    'hsl(320, 70%, 60%)',
    'hsl(200, 70%, 60%)'
  ];
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
};

const getUserInitials = (username: string) => {
  return username.slice(0, 2).toUpperCase();
};

export default function ChatPanel({
  isOpen = true,
  onToggle,
  messages = [],
  users = [],
  currentUsername = '',
  onSendMessage,
  className,
  inlineMode = false
}: ChatPanelProps) {
  const [messageInput, setMessageInput] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      onSendMessage?.(messageInput);
      setMessageInput('');
      console.log('Message sent:', messageInput);
    }
  };

  const handleToggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
    onToggle?.();
    console.log('Chat panel toggled');
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ru-RU', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className={cn(
      "flex flex-col bg-card h-full transition-all duration-300",
      !inlineMode && "border-l border-border",
      !inlineMode && (isCollapsed ? "w-12" : "w-80"),
      className
    )}>
      {/* Header - Only show in desktop mode */}
      {!inlineMode && (
        <div className="flex items-center justify-between p-4 border-b border-border">
          {!isCollapsed && (
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Чат</h3>
              <Badge variant="secondary" className="ml-auto">
                {users.length}
              </Badge>
            </div>
          )}
          <Button
            size="icon"
            variant="ghost"
            onClick={handleToggleCollapse}
            data-testid="button-toggle-chat"
            className="ml-auto"
          >
            {isCollapsed ? <MessageCircle className="w-4 h-4" /> : <X className="w-4 h-4" />}
          </Button>
        </div>
      )}

      {(!isCollapsed || inlineMode) && (
        <>
          {/* Participants List */}
          <div className="p-3 md:p-4 border-b border-border">
            <div className="flex items-center gap-2 mb-2 md:mb-3">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs md:text-sm font-medium">Участники</span>
            </div>
            <div className="space-y-1.5 md:space-y-2 max-h-20 md:max-h-24 overflow-y-auto">
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-2" data-testid={`user-${user.id}`}>
                  <Avatar className="w-5 h-5 md:w-6 md:h-6">
                    <AvatarFallback 
                      className="text-[10px] md:text-xs font-semibold text-white"
                      style={{ backgroundColor: user.color }}
                    >
                      {getUserInitials(user.username)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs md:text-sm truncate flex-1">{user.username}</span>
                  {user.isHost && (
                    <Badge variant="outline" className="text-[10px] md:text-xs px-1 py-0">
                      хост
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-3 md:p-4" data-testid="chat-messages">
            <div className="space-y-2.5 md:space-y-3">
              {messages.map((message) => (
                <div key={message.id} className="group">
                  {message.type === 'system' ? (
                    <div className="text-center">
                      <Badge variant="secondary" className="text-[10px] md:text-xs">
                        {message.content}
                      </Badge>
                    </div>
                  ) : (
                    <div className="flex gap-1.5 md:gap-2">
                      <Avatar className="w-6 h-6 md:w-7 md:h-7 mt-0.5 flex-shrink-0">
                        <AvatarFallback 
                          className="text-[10px] md:text-xs font-semibold text-white"
                          style={{ backgroundColor: message.userColor || getUserColor(message.username || '') }}
                        >
                          {getUserInitials(message.username || '')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-1.5 md:gap-2 mb-0.5 md:mb-1">
                          <span className="font-medium text-xs md:text-sm truncate">{message.username}</span>
                          <span className="text-[10px] md:text-xs text-muted-foreground font-mono flex-shrink-0">
                            {formatTime(message.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs md:text-sm break-words leading-relaxed">{message.content}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Message Input */}
          <div className="p-3 md:p-4 border-t border-border pb-[max(0.75rem,env(safe-area-inset-bottom))]">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Сообщение..."
                className="flex-1 h-9 md:h-10 text-sm md:text-base"
                data-testid="input-chat-message"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                data-testid="button-send-message"
                className="h-9 w-9 md:h-10 md:w-10 flex-shrink-0"
                size="icon"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}