import { useState, useEffect } from 'react';
import VideoPlayer from './VideoPlayer';
import ChatPanel from './ChatPanel';
import RoomHeader from './RoomHeader';
import RoomSettings from './RoomSettings';
import { Button } from '@/components/ui/button';
import { MessageCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface WatchRoomProps {
  roomId: string;
  currentUser: User;
  users?: User[];
  messages?: Message[];
  videoUrl?: string;
  initialCurrentTime?: number;
  initialIsPlaying?: boolean;
  isConnected?: boolean;
  onVideoLoad?: (url: string) => void;
  onPlay?: (currentTime: number) => void;
  onPause?: (currentTime: number) => void;
  onSeek?: (time: number) => void;
  onSendMessage?: (message: string) => void;
  onLeaveRoom?: () => void;
  onRoomSettings?: () => void;
}

export default function WatchRoom({
  roomId,
  currentUser,
  users = [],
  messages = [],
  videoUrl,
  initialCurrentTime,
  initialIsPlaying,
  isConnected = true,
  onVideoLoad,
  onPlay,
  onPause,
  onSeek,
  onSendMessage,
  onLeaveRoom,
  onRoomSettings
}: WatchRoomProps) {
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isMobileChatCollapsed, setIsMobileChatCollapsed] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleRoomSettings = () => {
    setIsSettingsOpen(true);
  };

  // Prevent body scroll on mobile
  useEffect(() => {
    const isRoom = true;
    if (isRoom && window.innerWidth < 768) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, []);

  return (
    <div className="h-[100svh] md:min-h-screen flex flex-col bg-background overflow-hidden md:overflow-visible">
      {/* Header */}
      <RoomHeader
        roomId={roomId}
        participantCount={users.length}
        isHost={currentUser.isHost}
        onLeaveRoom={onLeaveRoom}
        onRoomSettings={handleRoomSettings}
      />

      {/* Main Content - Different layouts for mobile vs desktop */}
      <div className="flex flex-1 overflow-hidden md:flex-row flex-col">
        {/* Desktop Layout */}
        <div className="hidden md:flex flex-1 min-w-0">
          <div className="flex-1 p-4">
            <VideoPlayer
              isHost={currentUser.isHost}
              isConnected={isConnected}
              participantCount={users.length}
              videoUrl={videoUrl}
              initialCurrentTime={initialCurrentTime}
              initialIsPlaying={initialIsPlaying}
              onVideoLoad={onVideoLoad}
              onPlay={onPlay}
              onPause={onPause}
              onSeek={onSeek}
            />
          </div>
        </div>

        {/* Desktop Chat Panel */}
        <div className={cn(
          "hidden md:flex transition-all duration-300 flex-shrink-0 border-l border-border",
          isChatOpen ? "w-80 min-w-0 max-w-[min(380px,40vw)]" : "w-0"
        )}>
          {isChatOpen && (
            <ChatPanel
              messages={messages}
              users={users}
              currentUsername={currentUser.username}
              onSendMessage={onSendMessage}
              onToggle={() => setIsChatOpen(false)}
              className="w-full"
            />
          )}
        </div>

        {/* Chat Toggle Button for Desktop */}
        {!isChatOpen && (
          <div className="hidden md:flex items-center justify-center p-2 border-l border-border flex-shrink-0 w-12">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsChatOpen(true)}
              data-testid="button-open-chat"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Mobile Layout - Video and Chat in single screen */}
        <div className="md:hidden flex flex-col flex-1 overflow-hidden">
          {/* Video Area */}
          <div className="flex-shrink-0">
            <div className="p-2">
              <VideoPlayer
                isHost={currentUser.isHost}
                isConnected={isConnected}
                participantCount={users.length}
                videoUrl={videoUrl}
                initialCurrentTime={initialCurrentTime}
                initialIsPlaying={initialIsPlaying}
                onVideoLoad={onVideoLoad}
                onPlay={onPlay}
                onPause={onPause}
                onSeek={onSeek}
              />
            </div>
          </div>

          {/* Mobile Chat - Inline with collapse */}
          <div className={cn(
            "flex flex-col border-t border-border transition-all duration-300 overflow-hidden",
            isMobileChatCollapsed ? "h-12" : "flex-1 min-h-0"
          )}>
            {/* Chat Toggle Header */}
            <div className="flex-shrink-0 flex items-center justify-between p-2 bg-card border-b border-border">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Чат</span>
                <span className="text-xs text-muted-foreground">
                  ({messages.filter(m => m.type === 'user').length})
                </span>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsMobileChatCollapsed(!isMobileChatCollapsed)}
                data-testid="button-toggle-mobile-chat"
                className="h-7 px-2"
              >
                {isMobileChatCollapsed ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </Button>
            </div>

            {/* Chat Content */}
            {!isMobileChatCollapsed && (
              <div className="flex-1 min-h-0 overflow-hidden">
                <ChatPanel
                  messages={messages}
                  users={users}
                  currentUsername={currentUser.username}
                  onSendMessage={onSendMessage}
                  inlineMode={true}
                  className="h-full w-full border-0 rounded-none"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Room Settings Dialog */}
      <RoomSettings
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        roomId={roomId}
        users={users}
        currentUser={currentUser}
        onUpdateSettings={(settings) => {
          console.log('Settings updated:', settings);
        }}
        onKickUser={(userId) => {
          console.log('Kick user:', userId);
        }}
        onPromoteUser={(userId) => {
          console.log('Promote user:', userId);
        }}
        onDeleteRoom={() => {
          console.log('Delete room');
          onLeaveRoom?.();
        }}
      />
    </div>
  );
}