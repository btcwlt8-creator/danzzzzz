# Design Guidelines: Synchronized Video Watching Platform

## Design Approach: Utility-Focused System
**Selected Approach:** Clean, functional design system inspired by modern streaming platforms like Netflix and Discord
**Justification:** This is a utility-focused application where synchronization accuracy, usability, and performance are paramount over visual flourishes.

## Core Design Principles
1. **Content First:** Video player is the primary focus, all other elements support this
2. **Minimal Distraction:** Clean interface that doesn't compete with video content
3. **Functional Clarity:** Every control and feature should be immediately understandable
4. **Responsive Unity:** Consistent experience across desktop and mobile

## Color Palette
**Primary Colors:**
- Background: 18 8% 8% (very dark gray)
- Surface: 20 6% 12% (dark gray cards/panels)
- Text Primary: 0 0% 95% (near white)
- Text Secondary: 0 0% 70% (medium gray)

**Accent Colors:**
- Primary Action: 220 100% 60% (bright blue for play/sync controls)
- Success: 120 60% 50% (green for connection status)
- Warning: 35 100% 55% (orange for host controls)

**Chat Colors:**
- User messages: 240 15% 20% (subtle blue-gray background)
- System messages: 60 15% 20% (subtle yellow-gray)

## Typography
**Font Stack:** Inter, -apple-system, BlinkMacSystemFont, sans-serif
- **Headers:** 600 weight, sizes 24px-32px
- **Body Text:** 400 weight, 14px-16px
- **UI Elements:** 500 weight, 12px-14px
- **Chat:** Monospace for timestamps, sans-serif for messages

## Layout System
**Spacing Units:** Tailwind spacing of 2, 4, 6, 8, 12, 16 units
- Tight spacing (p-2, m-2) for controls and buttons
- Medium spacing (p-4, gap-4) for component separation
- Large spacing (p-8, m-8) for major layout sections

## Component Library

### Video Player Area
- **Full-width responsive container** with 16:9 aspect ratio
- **Custom control overlay** with fade-in/out on hover
- **Sync status indicator** in top-right corner
- **Host-only upload button** prominently placed when no video loaded

### Chat Panel
- **Fixed sidebar on desktop** (300px width)
- **Collapsible overlay on mobile** (full-width when open)
- **Message bubbles** with user colors and timestamps
- **Input field** with send button and emoji picker

### Room Controls
- **Top navigation bar** with room ID, participant count
- **Copy room link button** with toast confirmation
- **Leave room button** with confirmation modal

### User Management
- **Nickname input modal** on first visit
- **Participant list** showing host designation
- **Simple avatar system** using initials in colored circles

## Responsive Behavior
**Desktop (1024px+):**
- Video player: 70% width, chat sidebar: 30%
- Controls overlay on video
- Horizontal layout

**Tablet (768px-1023px):**
- Video player: full width
- Chat: collapsible bottom panel
- Simplified controls

**Mobile (≤767px):**
- Video player: full width, 16:9 ratio
- Chat: slide-up overlay
- Touch-optimized controls
- Stack all elements vertically

## Animations
**Minimal and functional only:**
- Fade transitions for control overlays (200ms)
- Slide animations for mobile chat panel (300ms)
- Pulse effect for sync status indicators
- Smooth chat message entry

## Key Interactions
- **Click to play/pause** on video area
- **Tap controls** show/hide on mobile
- **Swipe up** to open chat on mobile
- **Long press** room link to copy on mobile

## Images
**No large hero image needed** - this is a functional application where the video content IS the primary visual element. Any graphics should be:
- **Icons only:** Simple, functional icons for controls
- **Placeholder graphics:** When no video is loaded, show a subtle upload prompt
- **Avatar placeholders:** Simple geometric patterns or initials for users

The design prioritizes functionality and synchronization reliability over decorative elements, ensuring users can focus on their shared viewing experience without interface distractions.