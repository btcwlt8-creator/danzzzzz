# Overview

SyncWatch is a synchronized video watching platform that enables users to watch videos together in real-time. The application allows users to create or join virtual rooms where they can share video content and communicate through an integrated chat system. The platform focuses on providing a seamless, synchronized viewing experience with minimal distractions from the video content.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built with React and TypeScript, utilizing modern development practices:

**UI Framework**: React with TypeScript for type safety and component-based architecture
- Uses Vite as the build tool for fast development and optimized production builds
- Implements a component-driven design using shadcn/ui component library built on Radix UI primitives
- Styled with Tailwind CSS for utility-first styling approach with custom design tokens

**Routing**: Wouter for lightweight client-side routing
- Simple route-based navigation between welcome screen and watch rooms
- Minimal overhead compared to React Router for this use case

**State Management**: Local component state with React hooks
- Utilizes TanStack Query for server state management and caching
- Custom hooks for reusable stateful logic across components

**Design System**: Follows a utility-focused approach inspired by modern streaming platforms
- Dark theme optimized for video content consumption with carefully chosen color palette
- Clean, minimal interface that prioritizes video player and chat functionality
- Responsive design supporting both desktop and mobile experiences using custom breakpoints
- Component examples provided for development and testing

## Backend Architecture
The server-side application uses Express.js with a modular, interface-driven architecture:

**Web Framework**: Express.js with TypeScript
- RESTful API structure with organized route handlers
- Middleware for request logging, error handling, and request processing
- Session management capabilities using connect-pg-simple for PostgreSQL session storage

**Development Setup**: Hot reloading and development tools
- Vite integration for seamless full-stack development experience
- TSX for TypeScript execution in development mode
- Custom error overlay and development banners for Replit environment

**Storage Interface**: Abstracted storage layer with pluggable implementations
- Interface-based design (IStorage) allowing for easy database switching
- Currently uses MemStorage for development with basic user management
- Designed to support PostgreSQL through Drizzle ORM for production

## Data Storage Solutions
The application is configured for PostgreSQL with Drizzle ORM:

**Database**: PostgreSQL with Neon serverless configuration
- Drizzle ORM for type-safe database operations and schema management
- Migration system for database schema versioning
- User schema with username/password authentication structure

**Session Management**: PostgreSQL-backed sessions
- Uses connect-pg-simple for storing session data in the database
- Enables persistent user sessions across server restarts

**Development Storage**: In-memory storage implementation
- MemStorage class provides development-friendly user management
- Easily replaceable with database implementation for production

## External Dependencies

**Database Services**:
- Neon Database (serverless PostgreSQL) for production data storage
- Drizzle ORM for database schema management and type-safe queries

**UI Component Libraries**:
- Radix UI primitives for accessible, unstyled UI components
- shadcn/ui for pre-built component implementations
- Lucide React for consistent iconography

**Development Tools**:
- Vite for build tooling and development server
- TanStack Query for server state management
- Wouter for lightweight routing
- Tailwind CSS for utility-first styling

**Utility Libraries**:
- class-variance-authority for component variant management
- clsx and tailwind-merge for conditional CSS class handling
- date-fns for date manipulation and formatting
- nanoid for generating unique identifiers

**Authentication & Security**:
- Built-in session management with PostgreSQL backing
- Password handling through user schema (implementation details in development)

The architecture prioritizes real-time synchronization capabilities, clean separation of concerns, and a mobile-responsive design that works seamlessly across different device types while maintaining focus on the video viewing experience.