# Overview

SyncWatch is a synchronized video watching platform that enables users to watch videos together in real-time. The application allows users to create or join virtual rooms where they can share video content and chat while maintaining perfect synchronization across all participants. Built as a full-stack TypeScript application, it features a React frontend with a modern UI and an Express.js backend with real-time capabilities.

# Recent Changes

**September 30, 2025 - Initial Replit Setup**
- Imported GitHub project and configured for Replit environment
- Installed Node.js 20 runtime and all npm dependencies
- Configured PostgreSQL database with environment variables (DATABASE_URL)
- Successfully pushed database schema using Drizzle ORM
- Configured development workflow to run on port 5000 with Vite dev server
- Set up deployment configuration for VM deployment (supports WebSockets and session state)
- Verified application runs successfully with all features operational

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built with React and TypeScript, utilizing modern development practices:

**UI Framework**: React with TypeScript for type safety and component-based architecture
- Uses Vite as the build tool for fast development and optimized production builds
- Implements a component-driven design using shadcn/ui component library
- Styled with Tailwind CSS for utility-first styling approach

**State Management**: Local component state with React hooks
- Utilizes TanStack Query for server state management and caching
- Custom hooks for reusable stateful logic

**Routing**: Wouter for lightweight client-side routing
- Simple route-based navigation between welcome screen and watch rooms

**Design System**: Follows a utility-focused approach inspired by modern streaming platforms
- Dark theme optimized for video content consumption
- Clean, minimal interface that prioritizes video player and chat functionality
- Responsive design supporting both desktop and mobile experiences

## Backend Architecture
The server-side application uses Express.js with a modular architecture:

**Web Framework**: Express.js with TypeScript
- RESTful API structure with route organization
- Middleware for request logging and error handling
- Session management capabilities with connect-pg-simple

**Development Setup**: Hot reloading and development tools
- Vite integration for seamless full-stack development
- TSX for TypeScript execution in development

**Storage Interface**: Abstracted storage layer with in-memory implementation
- Interface-based design allowing for easy database switching
- Currently uses MemStorage for development with user management capabilities

## Data Storage Solutions
The application is configured for PostgreSQL with Drizzle ORM:

**Database**: PostgreSQL with Neon serverless configuration
- Drizzle ORM for type-safe database operations and migrations
- Schema-first approach with automatic TypeScript type generation

**Current State**: PostgreSQL database configured and provisioned
- Database schema pushed successfully with Drizzle ORM
- User management with username/password authentication structure
- Currently uses in-memory storage (MemStorage) but ready to switch to PostgreSQL

## Authentication and Authorization
Basic user authentication system:

**User Management**: Username-based identification system
- User creation and lookup capabilities
- Password storage (prepared for proper hashing in production)
- Host/participant role distinction for room management

**Session Management**: Prepared for session-based authentication
- Cookie-based session storage configuration
- Role-based permissions for video control (host vs participants)

## External Dependencies

**UI Components**: Radix UI primitives with shadcn/ui styling
- Comprehensive component library for accessible, customizable UI elements
- Includes dialogs, dropdowns, forms, and interactive components

**Development Tools**: 
- Replit-specific plugins for development environment integration
- Runtime error overlay and development banner for debugging

**Styling**: Tailwind CSS with custom design tokens
- Inter font family for consistent typography
- Custom color palette optimized for dark theme video watching

**Real-time Communication**: Architecture prepared for WebSocket integration
- Server setup ready for Socket.io or similar real-time libraries
- Chat and video synchronization event handling structure

**Video Handling**: Browser-native video element with custom controls
- Support for various video formats through HTML5 video
- Custom overlay controls for synchronized playback
- URL-based video loading system