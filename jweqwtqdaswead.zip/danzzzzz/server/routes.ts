import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface Room {
  id: string;
  host: User;
  participants: Map<string, User>;
  videoUrl?: string;
  currentTime: number;
  isPlaying: boolean;
  messages: Message[];
}

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface ClientConnection {
  ws: WebSocket;
  roomId: string;
  user: User;
}

const rooms = new Map<string, Room>();
const connections = new Map<WebSocket, ClientConnection>();

function generateRoomId(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function generateUserId(): string {
  return Math.random().toString(36).substring(2, 15);
}

function getUserColor(username: string): string {
  const colors = [
    'hsl(220, 70%, 60%)',
    'hsl(280, 70%, 60%)',
    'hsl(160, 70%, 50%)',
    'hsl(40, 70%, 60%)',
    'hsl(320, 70%, 60%)',
    'hsl(200, 70%, 60%)'
  ];
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

function broadcastToRoom(roomId: string, message: any, excludeWs?: WebSocket) {
  const room = rooms.get(roomId);
  if (!room) return;

  connections.forEach((conn, ws) => {
    if (conn.roomId === roomId && ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  });
}

function getRoomUsers(roomId: string): User[] {
  const room = rooms.get(roomId);
  if (!room) return [];
  return [room.host, ...Array.from(room.participants.values())];
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/ws'
  });

  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection');

    ws.on('message', (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'create-room': {
            const roomId = generateRoomId();
            const user: User = {
              id: generateUserId(),
              username: message.username,
              isHost: true,
              color: getUserColor(message.username)
            };

            const room: Room = {
              id: roomId,
              host: user,
              participants: new Map(),
              currentTime: 0,
              isPlaying: false,
              messages: []
            };

            rooms.set(roomId, room);
            connections.set(ws, { ws, roomId, user });

            ws.send(JSON.stringify({
              type: 'room-created',
              roomId,
              user,
              users: [user],
              messages: []
            }));

            console.log(`Room ${roomId} created by ${user.username}`);
            break;
          }

          case 'join-room': {
            const { roomId, username } = message;
            const room = rooms.get(roomId);

            if (!room) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'Комната не найдена'
              }));
              break;
            }

            const user: User = {
              id: generateUserId(),
              username,
              isHost: false,
              color: getUserColor(username)
            };

            room.participants.set(user.id, user);
            connections.set(ws, { ws, roomId, user });

            const joinMessage: Message = {
              id: generateUserId(),
              type: 'system',
              content: `${username} присоединился`,
              timestamp: new Date()
            };
            room.messages.push(joinMessage);

            const users = getRoomUsers(roomId);

            ws.send(JSON.stringify({
              type: 'room-joined',
              roomId,
              user,
              users,
              messages: room.messages,
              videoUrl: room.videoUrl,
              currentTime: room.currentTime,
              isPlaying: room.isPlaying
            }));

            broadcastToRoom(roomId, {
              type: 'user-joined',
              user,
              users,
              message: joinMessage
            }, ws);

            console.log(`User ${username} joined room ${roomId}`);
            break;
          }

          case 'video-load': {
            const conn = connections.get(ws);
            if (!conn || !conn.user.isHost) break;

            const room = rooms.get(conn.roomId);
            if (!room) break;

            room.videoUrl = message.url;
            room.currentTime = 0;
            room.isPlaying = false;

            broadcastToRoom(conn.roomId, {
              type: 'video-loaded',
              url: message.url
            });

            console.log(`Video loaded in room ${conn.roomId}: ${message.url}`);
            break;
          }

          case 'video-play': {
            const conn = connections.get(ws);
            if (!conn || !conn.user.isHost) break;

            const room = rooms.get(conn.roomId);
            if (!room) break;

            room.isPlaying = true;
            room.currentTime = message.currentTime || 0;

            broadcastToRoom(conn.roomId, {
              type: 'video-play',
              currentTime: room.currentTime
            }, ws);

            console.log(`Video play in room ${conn.roomId}`);
            break;
          }

          case 'video-pause': {
            const conn = connections.get(ws);
            if (!conn || !conn.user.isHost) break;

            const room = rooms.get(conn.roomId);
            if (!room) break;

            room.isPlaying = false;
            room.currentTime = message.currentTime || 0;

            broadcastToRoom(conn.roomId, {
              type: 'video-pause',
              currentTime: room.currentTime
            }, ws);

            console.log(`Video pause in room ${conn.roomId}`);
            break;
          }

          case 'video-seek': {
            const conn = connections.get(ws);
            if (!conn || !conn.user.isHost) break;

            const room = rooms.get(conn.roomId);
            if (!room) break;

            room.currentTime = message.currentTime;

            broadcastToRoom(conn.roomId, {
              type: 'video-seek',
              currentTime: message.currentTime
            }, ws);

            console.log(`Video seek in room ${conn.roomId} to ${message.currentTime}`);
            break;
          }

          case 'chat-message': {
            const conn = connections.get(ws);
            if (!conn) break;

            const room = rooms.get(conn.roomId);
            if (!room) break;

            const chatMessage: Message = {
              id: generateUserId(),
              type: 'user',
              username: conn.user.username,
              content: message.content,
              timestamp: new Date(),
              userColor: conn.user.color
            };

            room.messages.push(chatMessage);

            broadcastToRoom(conn.roomId, {
              type: 'chat-message',
              message: chatMessage
            });

            ws.send(JSON.stringify({
              type: 'chat-message',
              message: chatMessage
            }));

            console.log(`Chat message in room ${conn.roomId} from ${conn.user.username}`);
            break;
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      const conn = connections.get(ws);
      if (conn) {
        const room = rooms.get(conn.roomId);
        if (room) {
          if (conn.user.isHost) {
            broadcastToRoom(conn.roomId, {
              type: 'room-closed',
              message: 'Хост покинул комнату'
            });
            rooms.delete(conn.roomId);
            console.log(`Room ${conn.roomId} closed`);
          } else {
            room.participants.delete(conn.user.id);
            const leaveMessage: Message = {
              id: generateUserId(),
              type: 'system',
              content: `${conn.user.username} покинул комнату`,
              timestamp: new Date()
            };
            room.messages.push(leaveMessage);

            const users = getRoomUsers(conn.roomId);
            broadcastToRoom(conn.roomId, {
              type: 'user-left',
              userId: conn.user.id,
              users,
              message: leaveMessage
            });

            console.log(`User ${conn.user.username} left room ${conn.roomId}`);
          }
        }
        connections.delete(ws);
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  return httpServer;
}
