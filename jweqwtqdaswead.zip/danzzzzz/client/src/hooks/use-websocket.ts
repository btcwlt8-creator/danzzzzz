import { useEffect, useRef, useState, useCallback } from 'react';

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface RoomState {
  roomId: string;
  currentUser: User | null;
  users: User[];
  messages: Message[];
  videoUrl?: string;
  currentTime?: number;
  isPlaying?: boolean;
  isConnected: boolean;
}

export function useWebSocket() {
  const ws = useRef<WebSocket | null>(null);
  const [roomState, setRoomState] = useState<RoomState>({
    roomId: '',
    currentUser: null,
    users: [],
    messages: [],
    isConnected: false
  });

  const connect = useCallback(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      console.log('WebSocket connected');
      setRoomState(prev => ({ ...prev, isConnected: true }));
    };

    ws.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'room-created':
            setRoomState({
              roomId: data.roomId,
              currentUser: data.user,
              users: data.users,
              messages: data.messages,
              isConnected: true
            });
            window.history.pushState({}, '', `/room/${data.roomId}`);
            break;

          case 'room-joined':
            setRoomState({
              roomId: data.roomId,
              currentUser: data.user,
              users: data.users,
              messages: data.messages.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })),
              videoUrl: data.videoUrl,
              currentTime: data.currentTime,
              isPlaying: data.isPlaying,
              isConnected: true
            });
            break;

          case 'user-joined':
            setRoomState(prev => ({
              ...prev,
              users: data.users,
              messages: [...prev.messages, { ...data.message, timestamp: new Date(data.message.timestamp) }]
            }));
            break;

          case 'user-left':
            setRoomState(prev => ({
              ...prev,
              users: data.users,
              messages: [...prev.messages, { ...data.message, timestamp: new Date(data.message.timestamp) }]
            }));
            break;

          case 'video-loaded':
            setRoomState(prev => ({ ...prev, videoUrl: data.url }));
            break;

          case 'video-play':
          case 'video-pause':
          case 'video-seek':
            window.dispatchEvent(new CustomEvent('video-sync', { detail: data }));
            break;

          case 'chat-message':
            setRoomState(prev => ({
              ...prev,
              messages: [...prev.messages, { ...data.message, timestamp: new Date(data.message.timestamp) }]
            }));
            break;

          case 'room-closed':
            setRoomState({
              roomId: '',
              currentUser: null,
              users: [],
              messages: [],
              isConnected: false
            });
            window.location.href = '/';
            break;

          case 'error':
            console.error('WebSocket error:', data.message);
            break;
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.current.onclose = () => {
      console.log('WebSocket disconnected');
      setRoomState(prev => ({ ...prev, isConnected: false }));
    };

    ws.current.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      ws.current?.close();
    };
  }, [connect]);

  const createRoom = useCallback((username: string) => {
    ws.current?.send(JSON.stringify({ type: 'create-room', username }));
  }, []);

  const joinRoom = useCallback((roomId: string, username: string) => {
    ws.current?.send(JSON.stringify({ type: 'join-room', roomId, username }));
  }, []);

  const loadVideo = useCallback((url: string) => {
    ws.current?.send(JSON.stringify({ type: 'video-load', url }));
  }, []);

  const playVideo = useCallback((currentTime: number) => {
    ws.current?.send(JSON.stringify({ type: 'video-play', currentTime }));
  }, []);

  const pauseVideo = useCallback((currentTime: number) => {
    ws.current?.send(JSON.stringify({ type: 'video-pause', currentTime }));
  }, []);

  const seekVideo = useCallback((currentTime: number) => {
    ws.current?.send(JSON.stringify({ type: 'video-seek', currentTime }));
  }, []);

  const sendMessage = useCallback((content: string) => {
    ws.current?.send(JSON.stringify({ type: 'chat-message', content }));
  }, []);

  const leaveRoom = useCallback(() => {
    ws.current?.close();
    setRoomState({
      roomId: '',
      currentUser: null,
      users: [],
      messages: [],
      isConnected: false
    });
    window.location.href = '/';
  }, []);

  return {
    roomState,
    createRoom,
    joinRoom,
    loadVideo,
    playVideo,
    pauseVideo,
    seekVideo,
    sendMessage,
    leaveRoom
  };
}
