import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Send, Users, X, MessageCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  type: 'user' | 'system';
  username?: string;
  content: string;
  timestamp: Date;
  userColor?: string;
}

interface User {
  id: string;
  username: string;
  isHost: boolean;
  color: string;
}

interface ChatPanelProps {
  isOpen?: boolean;
  onToggle?: () => void;
  messages?: Message[];
  users?: User[];
  currentUsername?: string;
  onSendMessage?: (message: string) => void;
  className?: string;
}

const getUserColor = (username: string) => {
  const colors = [
    'hsl(220, 70%, 60%)',
    'hsl(280, 70%, 60%)', 
    'hsl(160, 70%, 50%)',
    'hsl(40, 70%, 60%)',
    'hsl(320, 70%, 60%)',
    'hsl(200, 70%, 60%)'
  ];
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
};

const getUserInitials = (username: string) => {
  return username.slice(0, 2).toUpperCase();
};

export default function ChatPanel({
  isOpen = true,
  onToggle,
  messages = [],
  users = [],
  currentUsername = '',
  onSendMessage,
  className
}: ChatPanelProps) {
  const [messageInput, setMessageInput] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      onSendMessage?.(messageInput);
      setMessageInput('');
      console.log('Message sent:', messageInput);
    }
  };

  const handleToggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
    onToggle?.();
    console.log('Chat panel toggled');
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ru-RU', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className={cn(
      "flex flex-col bg-card border-l border-border h-full transition-all duration-300",
      isCollapsed ? "w-12" : "w-80",
      className
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Чат</h3>
            <Badge variant="secondary" className="ml-auto">
              {users.length}
            </Badge>
          </div>
        )}
        <Button
          size="icon"
          variant="ghost"
          onClick={handleToggleCollapse}
          data-testid="button-toggle-chat"
          className="ml-auto"
        >
          {isCollapsed ? <MessageCircle className="w-4 h-4" /> : <X className="w-4 h-4" />}
        </Button>
      </div>

      {!isCollapsed && (
        <>
          {/* Participants List */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-2 mb-3">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Участники</span>
            </div>
            <div className="space-y-2 max-h-24 overflow-y-auto">
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-2" data-testid={`user-${user.id}`}>
                  <Avatar className="w-6 h-6">
                    <AvatarFallback 
                      className="text-xs font-semibold text-white"
                      style={{ backgroundColor: user.color }}
                    >
                      {getUserInitials(user.username)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm truncate flex-1">{user.username}</span>
                  {user.isHost && (
                    <Badge variant="outline" className="text-xs px-1 py-0">
                      хост
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4" data-testid="chat-messages">
            <div className="space-y-3">
              {messages.map((message) => (
                <div key={message.id} className="group">
                  {message.type === 'system' ? (
                    <div className="text-center">
                      <Badge variant="secondary" className="text-xs">
                        {message.content}
                      </Badge>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Avatar className="w-7 h-7 mt-0.5">
                        <AvatarFallback 
                          className="text-xs font-semibold text-white"
                          style={{ backgroundColor: message.userColor || getUserColor(message.username || '') }}
                        >
                          {getUserInitials(message.username || '')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="font-medium text-sm truncate">{message.username}</span>
                          <span className="text-xs text-muted-foreground font-mono">
                            {formatTime(message.timestamp)}
                          </span>
                        </div>
                        <p className="text-sm break-words">{message.content}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Message Input */}
          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Напишите сообщение..."
                className="flex-1"
                data-testid="input-chat-message"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                data-testid="button-send-message"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}