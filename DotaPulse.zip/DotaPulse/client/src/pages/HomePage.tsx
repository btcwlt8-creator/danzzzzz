import { useState } from "react";
import HeroSearchBar from "@/components/HeroSearchBar";
import PlayerHeader from "@/components/PlayerHeader";
import StatCard from "@/components/StatCard";
import WinRateChart from "@/components/WinRateChart";
import HeroStatsCard from "@/components/HeroStatsCard";
import MatchCard from "@/components/MatchCard";
import MatchFilters from "@/components/MatchFilters";
import NavBar from "@/components/NavBar";
import { Trophy, Target, Swords, Clock } from "lucide-react";
import heroBannerImage from "@assets/generated_images/Dota_2_hero_banner_1d8b6bfd.png";

export default function HomePage() {
  const [showStats, setShowStats] = useState(false);

  const handleSearch = (url: string) => {
    console.log("Searching for:", url);
    setShowStats(true);
  };

  // todo: remove mock functionality - Mock data for demonstration
  const mockRecentMatches = [
    { result: "win" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
    { result: "win" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
  ];

  const mockMatches = [
    {
      matchId: 7123456789,
      heroName: "Invoker",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/invoker.png",
      result: "victory" as const,
      kills: 12,
      deaths: 3,
      assists: 18,
      duration: "42:15",
      items: ["item1", "item2", "item3", "item4", "item5", "item6"],
      gameMode: "Ranked All Pick",
      date: "2 hours ago",
    },
    {
      matchId: 7123456788,
      heroName: "Phantom Assassin",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/phantom_assassin.png",
      result: "defeat" as const,
      kills: 8,
      deaths: 9,
      assists: 6,
      duration: "38:42",
      items: ["item1", "item2", "item3", "item4", "item5", "item6"],
      gameMode: "Ranked All Pick",
      date: "5 hours ago",
    },
    {
      matchId: 7123456787,
      heroName: "Crystal Maiden",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/crystal_maiden.png",
      result: "victory" as const,
      kills: 3,
      deaths: 5,
      assists: 22,
      duration: "51:33",
      items: ["item1", "item2", "item3", "item4", "item5", "item6"],
      gameMode: "Ranked All Pick",
      date: "1 day ago",
    },
  ];

  const mockHeroes = [
    {
      heroName: "Invoker",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/invoker.png",
      games: 89,
      wins: 52,
      losses: 37,
      avgKDA: "4.2",
    },
    {
      heroName: "Phantom Assassin",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/phantom_assassin.png",
      games: 67,
      wins: 31,
      losses: 36,
      avgKDA: "3.8",
    },
    {
      heroName: "Pudge",
      heroImage: "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/pudge.png",
      games: 54,
      wins: 35,
      losses: 19,
      avgKDA: "3.1",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <NavBar />

      {!showStats ? (
        <div className="relative">
          <div className="absolute inset-0 z-0">
            <img
              src={heroBannerImage}
              alt="Dota 2 Background"
              className="w-full h-[600px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background" />
          </div>

          <div className="relative z-10 container mx-auto px-4 py-32">
            <div className="text-center mb-12">
              <h1 className="text-5xl md:text-6xl font-display font-bold mb-4 text-foreground">
                Track Your Dota 2 Journey
              </h1>
              <p className="text-xl text-foreground/90 max-w-2xl mx-auto">
                Enter your Steam profile URL to view detailed statistics, match history, and performance analytics
              </p>
            </div>

            <div className="flex justify-center">
              <HeroSearchBar onSearch={handleSearch} />
            </div>
          </div>
        </div>
      ) : (
        <div className="container mx-auto px-4 py-8">
          <div className="space-y-6">
            <PlayerHeader
              name="ProPlayer123"
              avatar="https://avatars.steamstatic.com/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg"
              rank="Divine IV"
              rankTier={4850}
            />

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <StatCard title="Total Matches" value="1,234" subtitle="+12 this week" icon={Trophy} trend="up" />
              <StatCard title="Win Rate" value="54.2%" subtitle="+2.1% this month" icon={Target} trend="up" />
              <StatCard title="Average KDA" value="3.45" subtitle="Last 20 games" icon={Swords} trend="neutral" />
              <StatCard title="Avg Duration" value="42:15" subtitle="Per match" icon={Clock} trend="neutral" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h2 className="text-2xl font-display font-bold mb-4">Match History</h2>
                  <MatchFilters />
                  <div className="space-y-3 mt-4">
                    {mockMatches.map((match) => (
                      <MatchCard key={match.matchId} {...match} />
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <WinRateChart recentMatches={mockRecentMatches} />

                <div>
                  <h3 className="text-xl font-display font-bold mb-4">Top Heroes</h3>
                  <div className="space-y-3">
                    {mockHeroes.map((hero) => (
                      <HeroStatsCard key={hero.heroName} {...hero} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
