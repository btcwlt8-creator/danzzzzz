import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";

interface MatchCardProps {
  matchId: number;
  heroName: string;
  heroImage: string;
  result: "victory" | "defeat";
  kills: number;
  deaths: number;
  assists: number;
  duration: string;
  items: string[];
  gameMode: string;
  date: string;
  onClick?: () => void;
}

export default function MatchCard({
  matchId,
  heroName,
  heroImage,
  result,
  kills,
  deaths,
  assists,
  duration,
  items,
  gameMode,
  date,
  onClick,
}: MatchCardProps) {
  const isVictory = result === "victory";
  const resultColor = isVictory ? "text-primary" : "text-destructive";
  const resultBg = isVictory ? "bg-primary/10" : "bg-destructive/10";

  return (
    <Card
      className={`p-4 hover-elevate active-elevate-2 cursor-pointer transition-all duration-150 ${resultBg} border-l-4 ${isVictory ? "border-l-primary" : "border-l-destructive"}`}
      onClick={() => {
        console.log("Match card clicked:", matchId);
        onClick?.();
      }}
      data-testid={`card-match-${matchId}`}
    >
      <div className="flex items-center gap-4">
        <div className="flex-shrink-0">
          <img src={heroImage} alt={heroName} className="w-16 h-16 rounded-md" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-display font-semibold text-lg" data-testid="text-hero-name">
              {heroName}
            </h3>
            <Badge variant={isVictory ? "default" : "destructive"} className="font-display" data-testid="text-result">
              {result.toUpperCase()}
            </Badge>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className={`font-display font-bold ${resultColor}`} data-testid="text-kda">
              {kills}/{deaths}/{assists}
            </span>
            <span data-testid="text-duration">{duration}</span>
            <span data-testid="text-game-mode">{gameMode}</span>
            <span className="text-xs" data-testid="text-date">{date}</span>
          </div>

          <div className="flex gap-1 mt-2">
            {items.map((item, index) => (
              <div key={index} className="w-10 h-8 bg-card rounded border border-card-border" title={item} />
            ))}
          </div>
        </div>

        <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
      </div>
    </Card>
  );
}
