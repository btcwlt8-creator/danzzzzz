import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

interface HeroSearchBarProps {
  onSearch?: (url: string) => void;
}

export default function HeroSearchBar({ onSearch }: HeroSearchBarProps) {
  const [searchValue, setSearchValue] = useState("");

  const handleSearch = () => {
    console.log("Search triggered for:", searchValue);
    onSearch?.(searchValue);
  };

  return (
    <div className="w-full max-w-2xl">
      <div className="flex gap-2">
        <Input
          type="text"
          placeholder="Enter Steam profile URL..."
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          className="h-12 bg-card/50 backdrop-blur-sm border-border text-base"
          data-testid="input-steam-url"
        />
        <Button
          onClick={handleSearch}
          className="h-12 px-6"
          data-testid="button-search"
        >
          <Search className="w-5 h-5 mr-2" />
          Search
        </Button>
      </div>
    </div>
  );
}
