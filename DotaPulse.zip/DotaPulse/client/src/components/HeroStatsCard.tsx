import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface HeroStatsCardProps {
  heroName: string;
  heroImage: string;
  games: number;
  wins: number;
  losses: number;
  avgKDA: string;
  onClick?: () => void;
}

export default function HeroStatsCard({
  heroName,
  heroImage,
  games,
  wins,
  losses,
  avgKDA,
  onClick,
}: HeroStatsCardProps) {
  const winRate = ((wins / games) * 100).toFixed(1);

  return (
    <Card
      className="p-4 hover-elevate active-elevate-2 cursor-pointer transition-all duration-150"
      onClick={() => {
        console.log("Hero stats clicked:", heroName);
        onClick?.();
      }}
      data-testid={`card-hero-${heroName.toLowerCase().replace(/\s/g, "-")}`}
    >
      <div className="flex items-center gap-3 mb-3">
        <img src={heroImage} alt={heroName} className="w-12 h-12 rounded-md" />
        <div className="flex-1">
          <h3 className="font-display font-semibold" data-testid="text-hero-name">
            {heroName}
          </h3>
          <p className="text-sm text-muted-foreground" data-testid="text-games">
            {games} games
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Win Rate</span>
          <span className={`font-display font-semibold ${parseFloat(winRate) >= 50 ? "text-primary" : "text-destructive"}`} data-testid="text-winrate">
            {winRate}%
          </span>
        </div>
        <Progress value={parseFloat(winRate)} className="h-2" />

        <div className="flex justify-between text-sm pt-1">
          <span className="text-muted-foreground">Avg KDA</span>
          <span className="font-display font-semibold" data-testid="text-avg-kda">
            {avgKDA}
          </span>
        </div>
      </div>
    </Card>
  );
}
