import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: "up" | "down" | "neutral";
}

export default function StatCard({ title, value, subtitle, icon: Icon, trend }: StatCardProps) {
  const trendColor = trend === "up" ? "text-primary" : trend === "down" ? "text-destructive" : "text-muted-foreground";

  return (
    <Card className="p-6 hover-elevate transition-all duration-150">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-1" data-testid="text-stat-title">
            {title}
          </p>
          <p className="text-3xl font-display font-bold" data-testid="text-stat-value">
            {value}
          </p>
          {subtitle && (
            <p className={`text-sm mt-1 ${trendColor}`} data-testid="text-stat-subtitle">
              {subtitle}
            </p>
          )}
        </div>
        {Icon && (
          <div className="p-3 bg-primary/10 rounded-md">
            <Icon className="w-6 h-6 text-primary" />
          </div>
        )}
      </div>
    </Card>
  );
}
