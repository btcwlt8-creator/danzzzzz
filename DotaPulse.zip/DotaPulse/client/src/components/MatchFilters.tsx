import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Filter, X } from "lucide-react";
import { useState } from "react";

interface MatchFiltersProps {
  onFilterChange?: (filters: any) => void;
}

export default function MatchFilters({ onFilterChange }: MatchFiltersProps) {
  const [result, setResult] = useState<string>("all");
  const [gameMode, setGameMode] = useState<string>("all");
  const [hero, setHero] = useState<string>("");

  const handleReset = () => {
    setResult("all");
    setGameMode("all");
    setHero("");
    console.log("Filters reset");
    onFilterChange?.({});
  };

  return (
    <div className="bg-card p-4 rounded-lg border border-card-border">
      <div className="flex items-center gap-2 mb-3">
        <Filter className="w-4 h-4 text-primary" />
        <h3 className="font-display font-semibold">Filters</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <Select value={result} onValueChange={setResult}>
          <SelectTrigger data-testid="select-result">
            <SelectValue placeholder="Result" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Matches</SelectItem>
            <SelectItem value="victory">Victory</SelectItem>
            <SelectItem value="defeat">Defeat</SelectItem>
          </SelectContent>
        </Select>

        <Select value={gameMode} onValueChange={setGameMode}>
          <SelectTrigger data-testid="select-game-mode">
            <SelectValue placeholder="Game Mode" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Modes</SelectItem>
            <SelectItem value="ranked">Ranked</SelectItem>
            <SelectItem value="unranked">Unranked</SelectItem>
            <SelectItem value="turbo">Turbo</SelectItem>
          </SelectContent>
        </Select>

        <Input
          type="text"
          placeholder="Search hero..."
          value={hero}
          onChange={(e) => setHero(e.target.value)}
          data-testid="input-hero-search"
        />

        <Button variant="outline" onClick={handleReset} data-testid="button-reset-filters">
          <X className="w-4 h-4 mr-2" />
          Reset
        </Button>
      </div>
    </div>
  );
}
