import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface PlayerHeaderProps {
  name: string;
  avatar: string;
  rank?: string;
  rankTier?: number;
}

export default function PlayerHeader({ name, avatar, rank, rankTier }: PlayerHeaderProps) {
  return (
    <div className="flex items-center gap-4 p-6 bg-card rounded-lg border border-card-border">
      <Avatar className="w-20 h-20 border-2 border-primary">
        <AvatarImage src={avatar} alt={name} />
        <AvatarFallback className="text-2xl font-display">{name.slice(0, 2).toUpperCase()}</AvatarFallback>
      </Avatar>

      <div className="flex-1">
        <h1 className="text-3xl font-display font-bold mb-2" data-testid="text-player-name">
          {name}
        </h1>
        {rank && (
          <Badge variant="secondary" className="font-display" data-testid="text-rank">
            {rank}
          </Badge>
        )}
      </div>

      {rankTier && (
        <div className="text-right">
          <div className="text-4xl font-display font-bold text-primary" data-testid="text-rank-tier">
            {rankTier}
          </div>
          <div className="text-xs text-muted-foreground">MMR</div>
        </div>
      )}
    </div>
  );
}
