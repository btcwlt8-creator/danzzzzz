import HeroSearchBar from "../HeroSearchBar";

export default function HeroSearchBarExample() {
  return <HeroSearchBar />;
}
