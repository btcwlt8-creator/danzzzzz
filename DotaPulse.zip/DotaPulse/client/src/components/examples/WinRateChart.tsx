import WinRateChart from "../WinRateChart";

export default function WinRateChartExample() {
  const mockMatches = [
    { result: "win" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
    { result: "win" as const },
    { result: "win" as const },
    { result: "loss" as const },
    { result: "win" as const },
  ];

  return (
    <div className="p-4">
      <WinRateChart recentMatches={mockMatches} />
    </div>
  );
}
