import HeroStatsCard from "../HeroStatsCard";

export default function HeroStatsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      <HeroStatsCard
        heroName="Invoker"
        heroImage="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/invoker.png"
        games={89}
        wins={52}
        losses={37}
        avgKDA="4.2"
      />
      <HeroStatsCard
        heroName="Phantom Assassin"
        heroImage="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/phantom_assassin.png"
        games={67}
        wins={31}
        losses={36}
        avgKDA="3.8"
      />
      <HeroStatsCard
        heroName="Pudge"
        heroImage="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/pudge.png"
        games={54}
        wins={35}
        losses={19}
        avgKDA="3.1"
      />
    </div>
  );
}
