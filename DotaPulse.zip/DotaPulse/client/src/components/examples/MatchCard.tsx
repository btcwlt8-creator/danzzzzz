import MatchCard from "../MatchCard";

export default function MatchCardExample() {
  return (
    <div className="space-y-3 p-4">
      <MatchCard
        matchId={7123456789}
        heroName="Invoker"
        heroImage="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/invoker.png"
        result="victory"
        kills={12}
        deaths={3}
        assists={18}
        duration="42:15"
        items={["item1", "item2", "item3", "item4", "item5", "item6"]}
        gameMode="Ranked All Pick"
        date="2 hours ago"
      />
      <MatchCard
        matchId={7123456788}
        heroName="Phantom Assassin"
        heroImage="https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/phantom_assassin.png"
        result="defeat"
        kills={8}
        deaths={9}
        assists={6}
        duration="38:42"
        items={["item1", "item2", "item3", "item4", "item5", "item6"]}
        gameMode="Ranked All Pick"
        date="5 hours ago"
      />
    </div>
  );
}
