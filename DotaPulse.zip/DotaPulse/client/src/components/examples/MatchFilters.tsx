import MatchFilters from "../MatchFilters";

export default function MatchFiltersExample() {
  return (
    <div className="p-4">
      <MatchFilters />
    </div>
  );
}
