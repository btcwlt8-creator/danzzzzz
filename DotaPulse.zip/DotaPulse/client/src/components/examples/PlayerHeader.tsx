import PlayerHeader from "../PlayerHeader";

export default function PlayerHeaderExample() {
  return (
    <div className="p-4">
      <PlayerHeader
        name="ProPlayer123"
        avatar="https://avatars.steamstatic.com/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg"
        rank="Divine IV"
        rankTier={4850}
      />
    </div>
  );
}
