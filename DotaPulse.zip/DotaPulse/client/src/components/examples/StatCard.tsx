import StatCard from "../StatCard";
import { Trophy, Target, Swords } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      <StatCard title="Total Matches" value="1,234" subtitle="+12 this week" icon={Trophy} trend="up" />
      <StatCard title="Win Rate" value="54.2%" subtitle="+2.1% this month" icon={Target} trend="up" />
      <StatCard title="Average KDA" value="3.45" subtitle="Last 20 games" icon={Swords} trend="neutral" />
    </div>
  );
}
