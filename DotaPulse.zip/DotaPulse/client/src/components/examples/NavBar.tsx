import NavBar from "../NavBar";

export default function NavBarExample() {
  return <NavBar />;
}
