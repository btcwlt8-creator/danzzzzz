import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

interface WinRateChartProps {
  recentMatches: { result: "win" | "loss" }[];
}

export default function WinRateChart({ recentMatches }: WinRateChartProps) {
  const wins = recentMatches.filter((m) => m.result === "win").length;
  const losses = recentMatches.length - wins;
  const winRate = ((wins / recentMatches.length) * 100).toFixed(1);
  const isPositive = parseFloat(winRate) >= 50;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-lg">Recent Performance</h3>
        {isPositive ? (
          <TrendingUp className="w-5 h-5 text-primary" />
        ) : (
          <TrendingDown className="w-5 h-5 text-destructive" />
        )}
      </div>

      <div className="flex items-center gap-2 mb-4">
        {recentMatches.map((match, index) => (
          <div
            key={index}
            className={`h-8 flex-1 rounded ${match.result === "win" ? "bg-primary" : "bg-destructive"}`}
            title={match.result}
          />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-2xl font-display font-bold text-primary" data-testid="text-wins">
            {wins}
          </div>
          <div className="text-xs text-muted-foreground">Wins</div>
        </div>
        <div>
          <div className="text-2xl font-display font-bold text-destructive" data-testid="text-losses">
            {losses}
          </div>
          <div className="text-xs text-muted-foreground">Losses</div>
        </div>
        <div>
          <div className={`text-2xl font-display font-bold ${isPositive ? "text-primary" : "text-destructive"}`} data-testid="text-winrate-chart">
            {winRate}%
          </div>
          <div className="text-xs text-muted-foreground">Win Rate</div>
        </div>
      </div>
    </Card>
  );
}
