# Design Guidelines: Dota 2 Statistics Platform

## Design Approach

**Hybrid Approach**: Gaming aesthetic inspired by Dotabuff/OpenDota combined with Material Design principles for data-heavy components. This creates an immersive gaming experience while maintaining exceptional data readability and utility.

**Key References**: Dotabuff's dark gaming aesthetic, OpenDota's clean data presentation, with touches of esports broadcast overlays for visual impact.

**Design Principles**:
- Dark-first design optimized for extended viewing sessions
- Data hierarchy that makes critical stats instantly scannable
- Gaming immersion without sacrificing information density
- Performance-oriented layouts for quick insights

## Color Palette

**Dark Mode** (Primary):
- Background Base: 215 25% 12% (deep blue-gray)
- Surface Elevated: 215 20% 16% (lighter panels)
- Surface Accent: 215 25% 20% (hover states, cards)

**Brand Colors**:
- Primary (Radiant): 145 65% 45% (emerald green - winning team)
- Secondary (Dire): 0 75% 55% (crimson red - losing team)
- Accent (Highlight): 210 100% 60% (electric blue - interactive elements)
- Neutral: 215 15% 65% (cool gray for secondary text)

**Semantic Colors**:
- Victory: 145 65% 45%
- Defeat: 0 65% 50%
- Warning/Neutral: 45 90% 55%
- Data Positive: 160 70% 50%
- Data Negative: 355 70% 55%

## Typography

**Font Families**:
- Primary: 'Inter' (stats, UI, body text)
- Display: 'Rajdhani' (headers, hero names, large numbers)
- Mono: 'JetBrains Mono' (match IDs, precise stats)

**Hierarchy**:
- Hero/Page Titles: Rajdhani 700, 2.5rem-4rem (dramatic headers)
- Section Headers: Rajdhani 600, 1.5rem-2rem
- Stats Numbers: Rajdhani 700, 1.25rem-3rem (KDA, winrate)
- Body/Labels: Inter 400, 0.875rem-1rem
- Small Stats: Inter 500, 0.75rem-0.875rem
- Match IDs/Codes: JetBrains Mono 400, 0.75rem

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16 (p-2, m-4, gap-6, py-8, px-12, space-y-16)

**Grid Strategy**:
- Dashboard: 12-column responsive grid
- Match Cards: 2-3 column grid on desktop, stack on mobile
- Hero Grid: 4-6 columns (desktop) → 2-3 (tablet) → 2 (mobile)
- Stats Panels: Flexible grid with auto-fit minmax(280px, 1fr)

**Container Widths**:
- Max content: max-w-7xl
- Forms/Search: max-w-2xl
- Data tables: w-full with horizontal scroll on mobile

## Component Library

### Navigation
- Sticky top navbar with glassmorphism effect (bg-opacity-90 backdrop-blur)
- Steam profile search bar prominently centered
- Quick stats summary in header (total matches, current rank badge)
- Mobile: Hamburger menu with slide-out drawer

### Hero Section
- **Large Hero Image**: YES - Dota 2 themed hero banner (1920x600px suggested)
  - Dark atmospheric Dota 2 battlefield scene or abstract hero silhouettes
  - Overlaid with glassmorphic search panel
  - Gradient overlay: from transparent to background color for seamless blend
  
### Player Profile Dashboard
- Hero card with player avatar, rank badge, and primary stats
- 4-column stat grid: Matches | Winrate | KDA | Most Played
- Recent performance graph (win/loss trend last 20 games)
- Top heroes carousel with mini-stats cards

### Match History List
- Card-based layout with alternating victory/defeat color coding
- Each card: Hero avatar | Result | KDA | Duration | Items | Expand arrow
- Filters bar: Hero selector, Result filter, Date range, Game mode
- Infinite scroll pagination

### Detailed Match Page
- Two-team layout (Radiant vs Dire) with hero portraits
- Expandable player rows showing:
  - Hero portrait, player name, level, KDA
  - Item progression timeline (6 item slots + backpack)
  - Skill build visualization (talent tree included)
- Match timeline graph showing gold/XP advantage over time
- Building damage, hero damage, heal stats in tabs

### Ward Map Visualization
- Interactive Dota 2 minimap as background
- Observer ward placements: green markers
- Sentry ward placements: blue markers
- Time-based filtering slider
- Heatmap overlay option
- Legend with ward counts and timing statistics

### Hero Statistics Page
- Hero grid with filter/search
- Per-hero cards: Portrait | Games | Winrate | Avg KDA | Last played
- Click to expand: Item builds frequency, skill progression patterns
- Performance radar chart (farming, fighting, support, pushing)

### Data Visualization Components
- Radial progress for winrates (circular progress bars)
- Linear stat bars with gradient fills
- Mini sparkline graphs for trends
- Comparison sliders (before/after, hero vs hero)
- Hexagonal stat displays for gaming aesthetic

### Forms & Inputs
- Dark mode optimized input fields (bg: 215 20% 16%, border: accent on focus)
- Autocomplete for hero/player search with avatar previews
- Toggle switches for filters (material design style)
- Date pickers with dark theme

### Cards & Panels
- Elevated cards: shadow-xl with subtle border (1px border-white/5)
- Stat cards: gradient backgrounds (primary/10 to transparent)
- Match cards: hover lift effect (scale-105 transition)
- Info panels: glassmorphic backgrounds for secondary data

## Images

**Hero Section**:
- Large hero banner (1920x600px): Dark Dota 2 battlefield or abstract hero composition
- Gradient overlay from transparent to background color
- Search panel with glassmorphic background overlaid on image

**Player Avatars**:
- Steam profile pictures (64x64px to 128x128px)
- Circular masks with rank border decoration

**Hero Portraits**:
- Official Dota 2 hero portraits throughout
- Various sizes: 32px (lists), 64px (cards), 128px (details), 256px (hero page)
- Hover effect: slight glow in hero's primary color

**Background Elements**:
- Subtle Dota 2 minimap pattern as page background (very low opacity ~5%)
- Ward map: Official Dota 2 minimap as interactive background
- Team logos/banners for Radiant/Dire in match details

**Icons**:
- Use Font Awesome for UI icons (sword, shield, clock, etc.)
- Dota 2 item icons via OpenDota API
- Ability icons via OpenDota API

## Responsive Behavior

**Mobile (< 768px)**:
- Single column layouts
- Collapsible stat sections with accordions
- Horizontal scroll for item builds (snap scroll)
- Bottom tab navigation for main sections
- Full-width hero cards with vertical stat layout
- Touch-optimized interactive elements (min 44px tap targets)

**Tablet (768px - 1024px)**:
- 2-column grids where appropriate
- Hybrid navigation (top bar + side drawer)
- Responsive tables with sticky columns

**Desktop (> 1024px)**:
- Multi-column data-rich layouts
- Hover interactions for detailed tooltips
- Side-by-side comparison views
- Expanded visualizations and charts

## Animations

**Minimal & Purposeful**:
- Page transitions: Simple fade-in (200ms)
- Card hover: Subtle lift and glow (transform + shadow, 150ms)
- Data loading: Skeleton screens with shimmer
- Victory/defeat reveals: Color pulse animation on match cards
- Stat counters: Count-up animation on initial load (once)
- NO distracting background animations
- NO excessive parallax effects