import { z } from "zod";

// Dota 2 Player Profile
export const playerProfileSchema = z.object({
  account_id: z.number(),
  personaname: z.string(),
  avatarfull: z.string(),
  profileurl: z.string(),
});

export type PlayerProfile = z.infer<typeof playerProfileSchema>;

// Dota 2 Win/Loss Stats
export const winLossSchema = z.object({
  win: z.number(),
  lose: z.number(),
});

export type WinLoss = z.infer<typeof winLossSchema>;

// Dota 2 Match
export const matchSchema = z.object({
  match_id: z.number(),
  player_slot: z.number(),
  radiant_win: z.boolean(),
  duration: z.number(),
  game_mode: z.number(),
  lobby_type: z.number(),
  hero_id: z.number(),
  start_time: z.number(),
  version: z.number().optional(),
  kills: z.number(),
  deaths: z.number(),
  assists: z.number(),
  skill: z.number().optional(),
  average_rank: z.number().optional(),
  leaver_status: z.number().optional(),
  party_size: z.number().optional(),
});

export type Match = z.infer<typeof matchSchema>;

// Hero Stats
export const heroStatsSchema = z.object({
  hero_id: z.number(),
  last_played: z.number(),
  games: z.number(),
  win: z.number(),
  with_games: z.number().optional(),
  with_win: z.number().optional(),
  against_games: z.number().optional(),
  against_win: z.number().optional(),
});

export type HeroStats = z.infer<typeof heroStatsSchema>;
